package com.liuyikun.aurora.service;

import com.liuyikun.aurora.domain.User;

/**
 * @author liuyikun
 * @date 2020/7/9 - 16:45
 */
public interface UserService {
	boolean registUser(User user);
}
